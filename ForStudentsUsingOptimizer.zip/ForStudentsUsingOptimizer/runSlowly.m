close all; clc; clear all;


ExampleMinimizingCostFunctionA(1);
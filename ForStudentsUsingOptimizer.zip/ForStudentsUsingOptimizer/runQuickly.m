close all; clc; clear all;



ExampleMinimizingCostFunctionA(0);